# CremaCozy

Espresso machine maintenance & cleaning guides (Breville Barista Express primary, Ninja Luxe Café secondary).
Jekyll site for GitHub Pages — free `username.github.io/cremacozy/` URL, no domain purchase.

## প্রথমবার চালু করা (আপনার করণীয়)

1. GitHub-এ ফ্রি অ্যাকাউন্ট খুলুন → `github.com/signup`  *(কাজের ধারাবাহিকতা #১)*
2. **Public** রিপোজিটরি বানান, নাম ঠিক `cremacozy`  *(#২)*
3. `_config.yml`-এ `YOUR-GITHUB-USERNAME` বদলে আপনার username বসান
4. এই ফোল্ডারের সব ফাইল রিপোতে আপলোড/push করুন
5. রিপো → **Settings → Pages → Build and deployment → Deploy from a branch → `main` / `(root)` → Save**  *(#৩)*
6. ১–২ মিনিট পর `https://<username>.github.io/cremacozy/` খুলুন

## নতুন আর্টিকেল যোগ করা

`_posts/YYYY-MM-DD-slug.md` ফাইল বানান (স্লাগই URL হবে: `/slug/`):

```yaml
---
layout: post
title: "How to Clean a Breville Barista Express: Step-by-Step Guide"
description: "Meta description, ≤155 অক্ষর"
categories: [breville-barista-express, cleaning-descaling]   # মেনুর ক্যাটেগরি স্লাগ
updated: 2026-09-30            # ঐচ্ছিক — "Last updated" দেখায়
related: [other-post-slug]     # ঐচ্ছিক — "Related guides" বক্স
---
```

## Amazon লিংকের নিয়ম (Monetization শীট)

- `<a class="aff" href="…" rel="sponsored nofollow noopener">Check price on Amazon</a>`
- বাটন চাইলে: `class="btn btn-cta"`
- **দাম/স্টক লিখবেন না**, Amazon-এর ছবি বসাবেন না (Creators API শর্ত পূরণ না হওয়া পর্যন্ত)

## কাস্টম ক্লাস

`.callout` / `.callout.warning` (টিপ/সেফটি বক্স) · `.table-wrap` (টেবিল র‍্যাপার) · `.btn-cta` · `.btn-secondary`

## যা এখনো নেই (পরের কাজ)

About, Contact, Privacy, Affiliate Disclosure, Terms, Cookie Policy পেজ (কাজ #৭–#১২) ও `sitemap.xml` (#২০) — এগুলো না বানানো পর্যন্ত মেনু/ফুটারের ওই লিংকগুলো 404 দেবে।
